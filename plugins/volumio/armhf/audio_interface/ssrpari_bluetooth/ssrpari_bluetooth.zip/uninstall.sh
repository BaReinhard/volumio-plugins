#!/bin/bash

# Uninstall dependendencies
# apt-get remove -y

echo "Done"
echo "pluginuninstallend"